

<script src="../ficiers-js/jquery-1.12.1.min.js"></script> 
<script src="../ficiers-js/bootstrap.min.js"></script>
<script src="../ficiers-js/Page-admin-js.js"></script>
<script src="../ficiers-js/PageMembre-js.js"></script>
<script src="../ficiers-js/add_Item-js.js"></script>
</body>
</html>